// Temporary shim to keep a couple dependencies working in Chromium.
#ifndef SkOrderedReadBuffer_DEFINED
#define SkOrderedReadBuffer_DEFINED

#include "src/core/SkReadBuffer.h"

typedef SkReadBuffer SkOrderedReadBuffer;

#endif//SkOrderedReadBuffer_DEFINED
